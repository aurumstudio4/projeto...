import React from 'react';
import { motion } from 'motion/react';
import { TESTIMONIALS, generateWhatsAppLink } from '../data/content';
import { Star, Quote, TrendingUp, MessageSquare, ArrowUpRight } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section id="depoimentos" className="py-24 bg-[#05080f] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="text-xs font-semibold uppercase tracking-wider text-blue-400">
            05. Quem confia e recomenda
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            O que nossos clientes dizem sobre os resultados
          </h2>
          <p className="text-slate-300 text-base sm:text-lg">
            Empresas reais que confiaram na AURUM studio para transformar sua presença digital e alavancar suas vendas.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="p-8 rounded-2xl bg-[#091122] border border-white/10 hover:border-blue-500/30 transition-all flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                {/* Rating & Result banner */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-400 tabular-nums">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{t.result}</span>
                  </div>
                </div>

                {/* Quote */}
                <div className="relative">
                  <Quote className="w-8 h-8 text-blue-500/20 absolute -top-2 -left-2 -z-0" />
                  <p className="text-slate-200 text-sm sm:text-base leading-relaxed relative z-10 italic">
                    "{t.quote}"
                  </p>
                </div>
              </div>

              {/* Author footer */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{t.name}</h4>
                  <div className="text-xs text-slate-400">
                    <span>{t.role}</span> · <span className="text-slate-300 font-medium">{t.company}</span>
                  </div>
                  <div className="text-[11px] text-slate-500">{t.location}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to action strip */}
        <div className="mt-16 p-8 rounded-2xl bg-gradient-to-r from-blue-950/60 via-[#091122] to-blue-950/60 border border-blue-500/30 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-white">Sua empresa pode ser o próximo case de sucesso</h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Entre em contato agora mesmo e tenha um site com entrega no mesmo dia.
            </p>
          </div>
          <a
            href={generateWhatsAppLink('Olá! Vi os depoimentos da AURUM studio e gostaria de solicitar meu orçamento.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shadow-md"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Solicitar Orçamento via WhatsApp</span>
            <ArrowUpRight className="w-4 h-4 text-blue-200" />
          </a>
        </div>
      </div>
    </section>
  );
};
