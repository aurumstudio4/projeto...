import React from 'react';
import { motion } from 'motion/react';
import { Clock, Zap, CheckCircle2, XCircle, MessageSquare, ArrowUpRight } from 'lucide-react';
import { PROCESS_STEPS, generateWhatsAppLink } from '../data/content';

export const DifferentiatorBanner: React.FC = () => {
  return (
    <section id="diferencial" className="py-24 bg-[#05080f] border-t border-b border-white/5 relative overflow-hidden">
      {/* Decorative ambient backdrop */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[350px] bg-blue-700/10 rounded-full blur-[160px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Headline */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="text-xs font-semibold uppercase tracking-wider text-blue-400">
            03. Nosso grande diferencial
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Por que esperar 30 dias se você pode começar a faturar hoje?
          </h2>
          <p className="text-slate-300 text-base sm:text-lg">
            A maioria das agências demora semanas criando apresentações burocráticas. Na <strong className="text-white">AURUM studio</strong>, eliminamos a enrolação e entregamos seu site pronto no mesmo dia.
          </p>
        </div>

        {/* 3 Steps Timeline / Process */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {PROCESS_STEPS.map((step, idx) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.15 }}
              className="p-8 rounded-2xl bg-[#091122] border border-white/10 relative hover:border-blue-500/30 transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-blue-400 font-mono">{step.step}</span>
                  <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-400" />
                    {step.time}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white">{step.title}</h3>
                <p className="text-sm text-slate-300 leading-relaxed">{step.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Direct Comparison: Tradicional vs AURUM */}
        <div className="max-w-4xl mx-auto rounded-2xl bg-[#080d1a] border border-white/10 p-6 sm:p-10">
          <h3 className="text-xl sm:text-2xl font-bold text-white text-center mb-8">
            Compare e veja a diferença prática para o seu bolso
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 divide-y md:divide-y-0 md:divide-x divide-white/10">
            {/* Outras agências */}
            <div className="space-y-4 pt-4 md:pt-0">
              <div className="flex items-center gap-2 text-rose-400 font-semibold text-sm">
                <XCircle className="w-5 h-5 shrink-0" />
                <span>Agências Tradicionais</span>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-400">
                <li className="flex items-center gap-2">
                  <span className="text-rose-400 font-bold">✕</span> 30 a 60 dias para entregar o primeiro layout
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-400 font-bold">✕</span> Reuniões intermináveis que atrasam o projeto
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-400 font-bold">✕</span> Sites pesados e cheios de plugins lentos
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-rose-400 font-bold">✕</span> Mensalidades abusivas e taxas escondidas
                </li>
              </ul>
            </div>

            {/* AURUM studio */}
            <div className="space-y-4 pt-6 md:pt-0 md:pl-8">
              <div className="flex items-center gap-2 text-blue-400 font-semibold text-sm">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>Método AURUM studio</span>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-200">
                <li className="flex items-center gap-2">
                  <span className="text-blue-400 font-bold">✓</span> <strong className="text-white">Entrega no mesmo dia</strong> (até 24h)
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-blue-400 font-bold">✓</span> Briefing ágil de 15 minutos via WhatsApp
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-blue-400 font-bold">✓</span> Código limpo, carregamento em 0.5s e foco em ROI
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-blue-400 font-bold">✓</span> Valor justo, sem mensalidade obrigatória
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-white/10 text-center">
            <a
              href={generateWhatsAppLink('Olá! Gostaria de um site com entrega no mesmo dia pela AURUM studio.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors shadow-lg shadow-blue-900/30"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Solicitar Orçamento via WhatsApp</span>
              <ArrowUpRight className="w-4 h-4 text-blue-200" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
