import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { BRAND_INFO, generateWhatsAppLink } from '../data/content';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2">
      {/* Interactive Micro Bubble */}
      {showTooltip && (
        <div className="relative max-w-xs p-3.5 rounded-2xl bg-[#091122] border border-blue-500/30 text-white shadow-2xl animate-fade-in text-xs space-y-1">
          <button
            type="button"
            onClick={() => setShowTooltip(false)}
            className="absolute top-2 right-2 text-slate-400 hover:text-white"
            aria-label="Fechar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <div className="font-bold text-blue-400 pr-4">AURUM studio · Online</div>
          <p className="text-slate-300">
            Precisa de um site profissional com entrega no mesmo dia? Toque aqui para solicitar seu orçamento!
          </p>
        </div>
      )}

      {/* WhatsApp Button */}
      <a
        href={generateWhatsAppLink(
          'Olá! Estou navegando no site da AURUM studio e gostaria de solicitar um orçamento rápido.'
        )}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Conversar no WhatsApp"
        className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white flex items-center justify-center shadow-xl shadow-emerald-950/40 hover:scale-105 active:scale-95 transition-all duration-200 border-2 border-emerald-400/40 relative group"
      >
        <MessageCircle className="w-7 h-7 fill-white/20" />
        <span className="sr-only">Falar no WhatsApp da AURUM studio</span>
      </a>
    </div>
  );
};
