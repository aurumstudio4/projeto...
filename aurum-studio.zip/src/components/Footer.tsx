import React from 'react';
import { BRAND_INFO, generateWhatsAppLink } from '../data/content';
import { MessageSquare, Instagram, ArrowUpRight, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#05080f] border-t border-white/10 text-slate-400 py-16 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12">
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2 text-xl font-bold tracking-tight text-white">
              <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-700 via-blue-900 to-black border border-blue-500/30 flex items-center justify-center text-white text-sm font-black shadow-inner">
                A
              </span>
              <span>
                AURUM <span className="text-blue-400 font-light">studio</span>
              </span>
            </div>

            <p className="text-slate-300 text-sm max-w-sm leading-relaxed">
              {BRAND_INFO.tagline}
            </p>

            <p className="text-xs text-slate-400">
              Especialistas em desenvolvimento de sites de alta conversão para empresas que buscam acelerar vendas e faturamento. Mais de 70 projetos vendidos e entrega expressa no mesmo dia.
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
              Navegação
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">Sobre Nós</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Nossos Serviços</a>
              </li>
              <li>
                <a href="#diferencial" className="hover:text-white transition-colors">Entrega no Mesmo Dia</a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">Depoimentos</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">Solicitar Orçamento</a>
              </li>
            </ul>
          </div>

          {/* Direct Channels */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
              Canais Oficiais
            </h4>
            <div className="space-y-2.5 text-xs sm:text-sm">
              <a
                href={generateWhatsAppLink('Olá! Vim pelo rodapé do site da AURUM studio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors group"
              >
                <MessageSquare className="w-4 h-4 text-blue-400" />
                <span className="font-semibold text-white">{BRAND_INFO.whatsappDisplay}</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white" />
              </a>

              <a
                href={BRAND_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors group"
              >
                <Instagram className="w-4 h-4 text-purple-400" />
                <span>{BRAND_INFO.instagramHandle}</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-white" />
              </a>

              <div className="pt-2 text-xs text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>Atendimento e entrega em todo o território nacional.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} AURUM studio. Todos os direitos reservados.
          </div>
          <div className="flex items-center gap-4">
            <span>Desenvolvido para alta conversão</span>
            <span aria-hidden="true">·</span>
            <a
              href={generateWhatsAppLink('Olá! Gostaria de falar sobre um projeto com a AURUM studio.')}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 font-medium"
            >
              Falar no WhatsApp
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
