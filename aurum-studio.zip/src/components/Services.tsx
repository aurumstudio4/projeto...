import React from 'react';
import { motion } from 'motion/react';
import { SERVICES, generateWhatsAppLink } from '../data/content';
import { ArrowUpRight, Check, Zap, MessageSquare } from 'lucide-react';

export const Services: React.FC = () => {
  return (
    <section id="servicos" className="py-24 bg-[#070b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="text-xs font-semibold uppercase tracking-wider text-blue-400">
            02. O que fazemos
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Criação de sites sob medida para escalar seu faturamento
          </h2>
          <p className="text-slate-300 text-base sm:text-lg">
            Soluções completas de desenvolvimento web com estética moderna, sem modelos genéricos e com a velocidade que o seu negócio precisa.
          </p>
        </div>

        {/* Services Grid (2x2 Asymmetric / Bento Feel) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="rounded-2xl bg-gradient-to-b from-[#0a1324] to-[#070b14] border border-white/10 p-8 flex flex-col justify-between hover:border-blue-500/40 transition-all duration-300 group"
            >
              <div className="space-y-6">
                {/* Header row: Number + Delivery indicator */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-mono font-bold text-blue-400 tracking-wider">
                    {service.number}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-blue-300 font-medium">
                    <Zap className="w-3.5 h-3.5 text-blue-400" />
                    <span>{service.deliveryBadge}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-white tracking-tight group-hover:text-blue-300 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm font-medium text-blue-200">
                    {service.headline}
                  </p>
                  <p className="text-sm text-slate-300 leading-relaxed pt-1">
                    {service.description}
                  </p>
                </div>

                {/* Benefits list */}
                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    O que está incluso:
                  </div>
                  <ul className="space-y-2">
                    {service.benefits.map((b, bIdx) => (
                      <li key={bIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                        <Check className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Ideal for note */}
                <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 text-xs text-slate-400">
                  <strong className="text-slate-300 font-medium">Ideal para:</strong> {service.idealFor}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Single clean CTA below the services grid */}
        <div className="mt-16 p-8 rounded-2xl bg-[#091122] border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div className="space-y-1">
            <h3 className="text-lg sm:text-xl font-bold text-white">
              Dúvida sobre qual formato é o ideal para sua empresa?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Analisamos seu nicho e indicamos a estrutura mais eficiente para alavancar suas vendas hoje.
            </p>
          </div>
          <a
            href={generateWhatsAppLink('Olá! Gostaria de uma recomendação sobre o melhor tipo de site para minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shadow-md shrink-0"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Falar com Especialista via WhatsApp</span>
            <ArrowUpRight className="w-4 h-4 text-blue-200" />
          </a>
        </div>
      </div>
    </section>
  );
};
