import React from 'react';
import { motion } from 'motion/react';
import { MessageSquare, ArrowUpRight, Clock, ShieldCheck, TrendingUp, Sparkles } from 'lucide-react';
import { BRAND_INFO, STATS, generateWhatsAppLink } from '../data/content';

export const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-gradient-to-b from-[#070b14] via-[#091122] to-[#070b14]">
      {/* Subtle deep navy ambient glow */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Copy & Value Proposition */}
          <div className="lg:col-span-7 space-y-8 text-left">
            {/* Tagline lead-in (clean unboxed text) */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-2 text-xs md:text-sm font-semibold tracking-wide uppercase text-blue-400"
            >
              <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
              <span>{BRAND_INFO.tagline}</span>
            </motion.div>

            {/* Display Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1] [text-wrap:balance]"
            >
              Sites que transformam visitas em vendas e{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-blue-400 to-indigo-300">
                multiplicam seu faturamento
              </span>
              .
            </motion.h1>

            {/* Subtitle / Persuasive Body */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-normal"
            >
              Criação profissional de sites e landing pages com design moderno, arquitetura minimalista
              e o nosso grande diferencial:{' '}
              <strong className="text-white font-semibold">entrega expressa no mesmo dia</strong>. Sem
              semanas de espera para colocar sua empresa no topo.
            </motion.p>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2"
            >
              <a
                href={generateWhatsAppLink(
                  'Olá! Quero solicitar um orçamento para meu site com entrega no mesmo dia pela AURUM studio.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 text-base font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl shadow-lg shadow-blue-900/30 transition-all duration-200 whitespace-nowrap group"
              >
                <MessageSquare className="w-5 h-5 text-white" />
                <span>Solicitar Orçamento via WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>

              <a
                href="#servicos"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-base font-medium text-slate-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-colors duration-200 whitespace-nowrap"
              >
                <span>Conhecer Serviços</span>
              </a>
            </motion.div>

            {/* Trust Markers strip (unboxed clean text) */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs sm:text-sm text-slate-400 border-t border-white/10"
            >
              <span className="flex items-center gap-1.5 text-slate-300">
                <Clock className="w-4 h-4 text-blue-400" />
                Entrega no Mesmo Dia
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <TrendingUp className="w-4 h-4 text-blue-400" />
                +70 Sites Vendidos
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                Suporte Completo & Domínio
              </span>
            </motion.div>
          </div>

          {/* Right Column: Visual Anchor / Hero Mockup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative rounded-2xl overflow-hidden border border-white/15 bg-gradient-to-b from-slate-900/80 to-[#070b14] shadow-2xl shadow-blue-950/50 group">
              {/* Top window frame styling */}
              <div className="h-8 bg-[#0b1325] border-b border-white/10 px-4 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                </div>
                <span className="text-[11px] text-slate-400 font-medium">aurumstudio.com.br</span>
                <div className="w-6" />
              </div>

              {/* High-res Hero Mockup */}
              <div className="relative aspect-[16/10] overflow-hidden bg-slate-950">
                <img
                  src="/src/assets/images/aurum_hero_showcase_1793975887175.jpg"
                  alt="Showcase de sites desenvolvidos pela AURUM studio"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070b14]/90 via-transparent to-transparent pointer-events-none" />

                {/* Overlaid Highlight Badge */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-[#091122]/90 backdrop-blur-md border border-white/15 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-white">AURUM studio — Performance Máxima</p>
                    <p className="text-[11px] text-slate-300">Tempo de carregamento: 0.5s · 100% Responsivo</p>
                  </div>
                  <span className="text-xs font-bold text-blue-400 tabular-nums">100/100 SEO</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Quantified Stats Grid (Full-width row below hero split) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-16 sm:mt-20 pt-12 border-t border-white/10 grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8"
        >
          {STATS.map((stat, idx) => (
            <div key={idx} className="space-y-1">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight tabular-nums">
                {stat.value}
              </div>
              <div className="text-sm font-semibold text-blue-400">{stat.label}</div>
              <div className="text-xs text-slate-400">{stat.note}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
