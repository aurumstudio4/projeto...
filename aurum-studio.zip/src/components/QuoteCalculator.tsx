import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BRAND_INFO, generateWhatsAppLink } from '../data/content';
import { MessageSquare, Send, CheckCircle2, Instagram, Phone, Clock, ArrowUpRight } from 'lucide-react';

export const QuoteCalculator: React.FC = () => {
  const [projectType, setProjectType] = useState<string>('Landing Page de Alta Conversão');
  const [deadline, setDeadline] = useState<string>('Entrega no Mesmo Dia (até 24h)');
  const [name, setName] = useState<string>('');
  const [company, setCompany] = useState<string>('');
  const [whatsapp, setWhatsapp] = useState<string>('');
  const [objective, setObjective] = useState<string>('Aumentar vendas e faturamento com tráfego pago');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const formattedMessage = `*SOLICITAÇÃO DE ORÇAMENTO — AURUM studio*
----------------------------------------
*Nome:* ${name || 'Não informado'}
*Empresa / Segmento:* ${company || 'Não informado'}
*WhatsApp do Cliente:* ${whatsapp || 'Não informado'}
*Tipo de Projeto:* ${projectType}
*Prazo Desejado:* ${deadline}
*Objetivo Principal:* ${objective}
----------------------------------------
Olá! Acabei de preencher o formulário no site da AURUM studio e gostaria de receber a proposta de orçamento.`;

    const link = generateWhatsAppLink(formattedMessage);
    setSubmitted(true);

    // Open WhatsApp in a new tab
    window.open(link, '_blank');
  };

  return (
    <section id="contato" className="py-24 bg-[#070b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Direct Contact & Guarantees */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <div className="text-xs font-semibold uppercase tracking-wider text-blue-400">
                06. Iniciar Projeto
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight [text-wrap:balance]">
                Vamos colocar seu novo site no ar hoje mesmo?
              </h2>
              <p className="text-slate-300 text-base leading-relaxed">
                Preencha o formulário ao lado para uma proposta imediata ou entre em contato diretamente pelo WhatsApp ou Instagram. Sem burocracia e com atendimento direto pelo especialista.
              </p>
            </div>

            {/* Direct Channel Cards */}
            <div className="space-y-4">
              {/* WhatsApp Card */}
              <a
                href={generateWhatsAppLink('Olá! Gostaria de falar com o time da AURUM studio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="p-5 rounded-2xl bg-[#091122] border border-white/10 hover:border-blue-500/40 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-105 transition-transform">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">WhatsApp Direto</div>
                    <div className="text-base font-bold text-white tabular-nums">{BRAND_INFO.whatsappDisplay}</div>
                    <div className="text-xs text-blue-400">Resposta em poucos minutos</div>
                  </div>
                </div>
                <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:text-white transition-colors" />
              </a>

              {/* Instagram Card */}
              <a
                href={BRAND_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-5 rounded-2xl bg-[#091122] border border-white/10 hover:border-blue-500/40 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-purple-600/20 to-pink-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300 group-hover:scale-105 transition-transform">
                    <Instagram className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-400 font-medium">Instagram Oficial</div>
                    <div className="text-base font-bold text-white">{BRAND_INFO.instagramHandle}</div>
                    <div className="text-xs text-slate-400">Acompanhe novos projetos e bastidores</div>
                  </div>
                </div>
                <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:text-white transition-colors" />
              </a>
            </div>

            {/* Quick Commitments */}
            <div className="pt-4 space-y-3 border-t border-white/10">
              <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-300">
                <Clock className="w-4 h-4 text-blue-400 shrink-0" />
                <span><strong className="text-white">Entrega no mesmo dia</strong> disponível para contratações no turno matutino</span>
              </div>
              <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Sem contratos longos ou mensalidades obrigatórias de manutenção</span>
              </div>
              <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Atendimento para empresas de qualquer estado do Brasil</span>
              </div>
            </div>
          </div>

          {/* Right Column: Lead Form that dispatches to WhatsApp */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="rounded-2xl bg-[#091122] border border-white/15 p-6 sm:p-10 shadow-2xl relative"
            >
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-white">Solicitar Orçamento Rápido</h3>
                <p className="text-slate-300 text-sm mt-1">
                  Selecione os parâmetros do seu projeto e envie os dados direto para o nosso WhatsApp.
                </p>
              </div>

              {submitted && (
                <div className="mb-6 p-4 rounded-xl bg-blue-900/30 border border-blue-500/40 text-blue-200 text-sm flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-400 shrink-0" />
                  <span>
                    Dados organizados com sucesso! Se a janela do WhatsApp não abriu automaticamente, clique no botão principal novamente.
                  </span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Project Type */}
                <div className="space-y-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Qual tipo de site você precisa?
                  </label>
                  <select
                    value={projectType}
                    onChange={(e) => setProjectType(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#060a14] border border-white/10 text-white text-sm focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
                  >
                    <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão (para anúncios)</option>
                    <option value="Site Institucional Completo">Site Institucional de Autoridade (Empresarial)</option>
                    <option value="Loja Virtual / E-commerce">Loja Virtual / Catálogo de Produtos</option>
                    <option value="Página de Vendas / Infoproduto">Página de Vendas / Lançamento</option>
                    <option value="Redesign e Otimização">Redesign e Aceleração de Site Existente</option>
                  </select>
                </div>

                {/* Urgency */}
                <div className="space-y-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Prazo desejado:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setDeadline('Entrega no Mesmo Dia (até 24h)')}
                      className={`px-4 py-3 rounded-xl text-xs font-semibold text-left transition-all border cursor-pointer ${
                        deadline.includes('Mesmo Dia')
                          ? 'bg-blue-600/20 border-blue-500 text-white'
                          : 'bg-[#060a14] border-white/10 text-slate-300 hover:text-white'
                      }`}
                    >
                      <div className="font-bold flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-blue-400" />
                        Entrega no Mesmo Dia
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Prioridade máxima em até 24h</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeadline('Prazo Padrão (2 a 4 dias úteis)')}
                      className={`px-4 py-3 rounded-xl text-xs font-semibold text-left transition-all border cursor-pointer ${
                        deadline.includes('Padrão')
                          ? 'bg-blue-600/20 border-blue-500 text-white'
                          : 'bg-[#060a14] border-white/10 text-slate-300 hover:text-white'
                      }`}
                    >
                      <div className="font-bold">Prazo Padrão</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">Entrega em 2 a 4 dias úteis</div>
                    </button>
                  </div>
                </div>

                {/* Name & Phone Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Seu Nome *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Carlos Eduardo"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#060a14] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                      Seu WhatsApp com DDD *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="Ex: (11) 98765-4321"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#060a14] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Company / Segment */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Nome da Empresa e Ramo de Atuação
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Clínica Alpha — Dermatologia"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#060a14] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 transition-colors"
                  />
                </div>

                {/* Objective */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Qual seu principal objetivo com o site?
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Ex: Quero rodar tráfego pago para captar mais clientes qualificados via WhatsApp..."
                    value={objective}
                    onChange={(e) => setObjective(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#060a14] border border-white/10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 transition-colors resize-none"
                  />
                </div>

                {/* Submit CTA */}
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-3 py-4 px-6 text-sm sm:text-base font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl transition-all shadow-lg shadow-blue-900/40 cursor-pointer"
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span>Solicitar Orçamento via WhatsApp</span>
                    <ArrowUpRight className="w-4 h-4 text-blue-200" />
                  </button>
                  <p className="text-center text-xs text-slate-400 mt-3">
                    Ao clicar, seus dados serão organizados e enviados diretamente para o WhatsApp da AURUM studio.
                  </p>
                </div>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
