import React from 'react';
import { motion } from 'motion/react';
import { Target, Zap, Rocket, CheckCircle2, MessageSquare, ArrowUpRight } from 'lucide-react';
import { BRAND_INFO, generateWhatsAppLink } from '../data/content';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-24 bg-[#05080f] relative overflow-hidden border-t border-white/5">
      {/* Background visual element */}
      <div
        className="absolute bottom-0 right-0 w-96 h-96 bg-blue-900/10 rounded-full blur-[120px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Story & Personal Narrative */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-6 space-y-6"
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-400">
              01. Quem somos
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight [text-wrap:balance]">
              A paixão por criar sites somada ao compromisso de ver empresas prosperarem.
            </h2>

            <div className="space-y-4 text-slate-300 text-base sm:text-lg leading-relaxed">
              <p>
                Sempre gostei muito de fazer sites, e me encontrei exatamente na interseção entre duas
                coisas que sou apaixonado: <span className="text-white font-medium">criar sites de alta qualidade</span> e{' '}
                <span className="text-white font-medium">ajudar empresas a subirem de nível no mercado com páginas bem desenvolvidas</span>.
              </p>
              <p>
                A <strong className="text-white font-semibold">AURUM studio</strong> nasceu dessa vontade. Já crio sites há{' '}
                <strong className="text-white font-semibold">8 meses</strong> e já são mais de{' '}
                <strong className="text-blue-400 font-semibold tabular-nums">+70 projetos vendidos</strong> e entregues para clientes de
                diversos segmentos em todo o Brasil.
              </p>
              <p className="text-slate-400 text-sm">
                Enquanto o mercado tradicional de agências cobra valores astronômicos e leva 30 a 60 dias para entregar um site básico, nós quebramos a burocracia: entregamos sites modernos, refinados e prontos para vender no mesmo dia.
              </p>
            </div>

            <div className="pt-2">
              <a
                href={generateWhatsAppLink('Olá! Quero conhecer mais sobre os sites da AURUM studio e solicitar um orçamento.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors duration-150 shadow-md group"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Solicitar Orçamento via WhatsApp</span>
                <ArrowUpRight className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>
          </motion.div>

          {/* Right Column: Pillars & Value Proof Bento */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-6 space-y-4"
          >
            {/* Card 1: Foco em Faturamento */}
            <div className="p-6 rounded-2xl bg-[#091122] border border-white/10 hover:border-blue-500/30 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center shrink-0 text-blue-400">
                  <Target className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-bold text-white">Foco Total em Faturamento</h3>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    Não fazemos apenas sites bonitos. Criamos ferramentas comerciais estruturadas para guiar o visitante até o clique de compra ou contato imediato.
                  </p>
                </div>
              </div>
            </div>

            {/* Card 2: Entrega no Mesmo Dia */}
            <div className="p-6 rounded-2xl bg-[#091122] border border-white/10 hover:border-blue-500/30 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center shrink-0 text-blue-400">
                  <Zap className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-bold text-white">Entrega no Mesmo Dia</h3>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    Tempo é dinheiro. Nosso fluxo otimizado permite construir, validar e publicar sua landing page ou site em poucas horas, sem atrasar suas campanhas.
                  </p>
                </div>
              </div>
            </div>

            {/* Card 3: Experiência Comprovada */}
            <div className="p-6 rounded-2xl bg-[#091122] border border-white/10 hover:border-blue-500/30 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center shrink-0 text-blue-400">
                  <Rocket className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-bold text-white">Mais de 70 Projetos Validados</h3>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    Experiência prática com dezenas de nichos: clínicas, comércio eletrônico, escritórios, consultorias, serviços locais e lançamentos digitais.
                  </p>
                </div>
              </div>
            </div>

            {/* Quality Checklist */}
            <div className="pt-2 grid grid-cols-2 gap-3 text-xs text-slate-300 font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Design 100% Exclusivo</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Velocidade Máxima (0.5s)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Responsivo para Celulares</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>WhatsApp Integrado</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
