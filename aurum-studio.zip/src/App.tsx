import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { DifferentiatorBanner } from './components/DifferentiatorBanner';
import { Testimonials } from './components/Testimonials';
import { QuoteCalculator } from './components/QuoteCalculator';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#070b14] text-white flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top 3-Zone Fixed Navbar */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero />
        <About />
        <Services />
        <DifferentiatorBanner />
        <Testimonials />
        <QuoteCalculator />
      </main>

      {/* Floating Lead Capture WhatsApp Button */}
      <FloatingWhatsApp />

      {/* Footer */}
      <Footer />
    </div>
  );
}
