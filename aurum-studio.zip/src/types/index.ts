export interface Project {
  id: string;
  title: string;
  category: 'landing' | 'ecommerce' | 'institucional' | 'vendas';
  categoryLabel: string;
  client: string;
  segment: string;
  metric: string;
  metricLabel: string;
  deliveryTime: string;
  image: string;
  description: string;
  features: string[];
  conversionFocus: string;
}

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  headline: string;
  description: string;
  deliveryBadge: string;
  benefits: string[];
  idealFor: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  location: string;
  result: string;
  quote: string;
  rating: number;
}
