import { Project, ServiceItem, TestimonialItem } from '../types';

export const BRAND_INFO = {
  name: 'AURUM studio',
  tagline: 'Sua marca merece mais que presença digital. Merece destaque.',
  subtagline: 'Sites profissionais que aceleram vendas e posicionam empresas como líderes no mercado.',
  aboutSummary:
    'Sempre gostei muito de fazer sites, e me encontrei com duas coisas que gosto: criar sites e ajudar as empresas a subirem no mercado com sites bem desenvolvidos. Já crio sites há 8 meses e tenho mais de 70 projetos vendidos em todo o Brasil.',
  whatsappRaw: '5517996839032',
  whatsappDisplay: '+55 (17) 99683-9032',
  instagramHandle: '@aurumstudiooficial_',
  instagramUrl: 'https://instagram.com/aurumstudiooficial_',
  differentiator: 'Entrega expressa no mesmo dia',
  location: 'Brasil · Atendimento Nacional',
};

export const generateWhatsAppLink = (customText?: string) => {
  const defaultText =
    'Olá! Vim pelo site da AURUM studio e gostaria de solicitar um orçamento para o meu site.';
  const message = customText ? customText : defaultText;
  return `https://wa.me/${BRAND_INFO.whatsappRaw}?text=${encodeURIComponent(message)}`;
};

export const STATS = [
  { value: '+70', label: 'Projetos Vendidos', note: 'Para empresas em todo o país' },
  { value: '24h', label: 'Entrega no Mesmo Dia', note: 'Sem semanas de enrolação' },
  { value: '8', label: 'Meses de Atuação', note: 'Crescimento e foco em resultados' },
  { value: '100%', label: 'Foco em ROI', note: 'Sites desenhados para faturar' },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'landing-pages',
    number: '01',
    title: 'Landing Pages de Alta Conversão',
    headline: 'Transforme cliques de anúncios em vendas imediatas',
    description:
      'Páginas de aterrissagem ultra velozes, com copywriting persuasivo e design focado em um único objetivo: fazer o cliente chamar no WhatsApp ou comprar o seu produto.',
    deliveryBadge: 'Entrega disponível no mesmo dia',
    benefits: [
      'Carregamento instantâneo em menos de 1 segundo',
      'Copywriting psicológico focado em quebra de objeções',
      'Integração direta com WhatsApp e Pixel de Anúncios',
      'Layout 100% responsivo e otimizado para celular',
    ],
    idealFor: 'Empresas rodando tráfego pago (Google Ads/Meta Ads) que precisam de leads rápidos.',
  },
  {
    id: 'institucionais',
    number: '02',
    title: 'Sites Institucionais de Autoridade',
    headline: 'Passe credibilidade imediata para fechar contratos de alto valor',
    description:
      'Apresentação corporativa impecável para o seu negócio. Seus clientes vão perceber que estão diante de uma empresa sólida, profissional e digna de confiança.',
    deliveryBadge: 'Entrega expressa em 24h a 48h',
    benefits: [
      'Identidade visual alinhada ao posicionamento premium',
      'Páginas institucionais, serviços, equipe e contato',
      'Otimização avançada para o Google (SEO local e nacional)',
      'Design limpo com muito espaço e hierarquia forte',
    ],
    idealFor: 'Clínicas médicas, escritórios de advocacia, consultorias e empresas B2B.',
  },
  {
    id: 'ecommerce',
    number: '03',
    title: 'Lojas Virtuais & Catálogos Digitais',
    headline: 'Sua vitrine moderna aberta 24 horas vendendo sem atrito',
    description:
      'Lojas modernas, intuitivas e seguras. Estrutura pensada para reduzir abandonos de carrinho e facilitar a compra em apenas alguns toques na tela.',
    deliveryBadge: 'Estruturação ágil e direta',
    benefits: [
      'Catálogo de produtos visualmente sofisticado',
      'Fluxo de checkout simplificado e seguro',
      'Opção de pedido direto via WhatsApp ou gateway de pagamento',
      'Painel intuitivo para gerenciamento de pedidos e estoque',
    ],
    idealFor: 'Marcas de vestuário, cosméticos, acessórios e produtos físicos.',
  },
  {
    id: 'redesign-performance',
    number: '04',
    title: 'Redesign & Otimização de Performance',
    headline: 'Recupere vendas perdidas por causa de um site lento e desatualizado',
    description:
      'Se o seu site atual parece antigo, demora para carregar ou não traz contatos, nós reconstruímos sua estrutura com arquitetura moderna, design minimalista e velocidade pura.',
    deliveryBadge: 'Reformulação expressa no mesmo dia',
    benefits: [
      'Melhoria drástica na pontuação Google PageSpeed (95+)',
      'Modernização estética conforme as tendências de 2026',
      'Reestruturação das chamadas para ação (CTAs)',
      'Recuperação do tráfego orgânico e taxa de conversão',
    ],
    idealFor: 'Negócios que já possuem site mas sentem que ele não gera vendas.',
  },
];

export const PROJECTS: Project[] = [
  {
    id: 'aura-clinic',
    title: 'Aura Clinic — Dermatologia & Estética Avançada',
    category: 'landing',
    categoryLabel: 'Landing Page',
    client: 'Aura Medicina e Estética',
    segment: 'Saúde & Estética Premium',
    metric: '+185%',
    metricLabel: 'Aumento em consultas agendadas via WhatsApp',
    deliveryTime: 'Entregue no mesmo dia (20h)',
    image: '/src/assets/images/portfolio_project_clinic_1793975888369.jpg',
    description:
      'Desenvolvimento de landing page de alta conversão para clínica dermatológica de alto padrão. Foco na transmissão de requinte médico, clareza nos procedimentos e botão fixo de agendamento.',
    features: [
      'Carregamento em 0.6s no celular',
      'Seletor interativo de especialidades médicas',
      'Galeria de resultados antes/depois com conformidade médica',
      'Disparo direto para o WhatsApp da recepção',
    ],
    conversionFocus: 'Tráfego pago no Google Ads para procedimentos de alto ticket.',
  },
  {
    id: 'aethel-store',
    title: 'Aethel — Moda Minimalista & Alfaiataria Contemporânea',
    category: 'ecommerce',
    categoryLabel: 'E-commerce & Catálogo',
    client: 'Aethel Brasil',
    segment: 'Moda & Luxo Acessível',
    metric: '+240%',
    metricLabel: 'Crescimento de faturamento no primeiro trimestre',
    deliveryTime: 'Desenvolvimento ágil em 48h',
    image: '/src/assets/images/portfolio_project_store_1793975888769.jpg',
    description:
      'Plataforma de e-commerce minimalista com paleta em tons sóbrios, valorizando a fotografia dos produtos e proporcionando uma experiência de compra sem fricção.',
    features: [
      'Checkout em 1 página com suporte a Pix instantâneo',
      'Filtros dinâmicos por tamanho e cor sem recarregar a tela',
      'Micro-animações elegantes em cada produto',
      'Recuperação de carrinho via WhatsApp automatizada',
    ],
    conversionFocus: 'Escalar vendas orgânicas e anúncios no Instagram/TikTok.',
  },
  {
    id: 'aurora-partners',
    title: 'Aurora Partners — Advocacia Empresarial & M&A',
    category: 'institucional',
    categoryLabel: 'Site Institucional',
    client: 'Aurora Sociedade de Advogados',
    segment: 'Jurídico Corporativo & Finanças',
    metric: 'R$ 1.8M',
    metricLabel: 'Em propostas solicitadas por clientes corporativos',
    deliveryTime: 'Entregue no mesmo dia (18h)',
    image: '/src/assets/images/portfolio_project_corp_1793975888276.jpg',
    description:
      'Site institucional para banca jurídica especializada em fusões e aquisições. Tipografia sóbria, hierarquia rígida e narrativa focada em segurança jurídica e grandes números.',
    features: [
      'Apresentação de sócios com currículo e credenciais',
      'Área de artigos e insights tributários para SEO',
      'Formulário confidencial para análise de demandas',
      'Versão multilíngue e total conformidade com a OAB',
    ],
    conversionFocus: 'Geração de reuniões estratégicas com diretores e CEOs.',
  },
  {
    id: 'alto-digital',
    title: 'Alto Digital — Soluções em Tecnologia & B2B',
    category: 'vendas',
    categoryLabel: 'Página de Vendas',
    client: 'Alto Tech Group',
    segment: 'Tecnologia & Software',
    metric: '+310%',
    metricLabel: 'Taxa de conversão em demonstrações de software',
    deliveryTime: 'Entregue no mesmo dia (12h)',
    image: '/src/assets/images/aurum_hero_showcase_1793975887175.jpg',
    description:
      'Página de demonstração e vendas com apresentação visual imersiva, comparativos de planos claros e depoimentos em vídeo.',
    features: [
      'Tabela comparativa interativa de planos',
      'Calculadora de economia de custos para o cliente',
      'Integração com CRM de vendas',
      'Tempo de resposta de página inferior a 0.5s',
    ],
    conversionFocus: 'Fechamento de contratos recorrentes (SaaS).',
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: '1',
    name: 'Dra. Camila Neves',
    role: 'Diretora Médica',
    company: 'Clínica Neves Estética',
    location: 'São Paulo - SP',
    result: '+38 novos pacientes no 1º mês',
    quote:
      'O que mais me impressionou na AURUM foi a agilidade: fechamos o briefing pela manhã e a landing page estava no ar no mesmo dia, às 20h! Ligamos os anúncios no dia seguinte e os agendamentos pelo WhatsApp não pararam mais.',
    rating: 5,
  },
  {
    id: '2',
    name: 'Marcos Vinicius Rezende',
    role: 'Fundador & CEO',
    company: 'MV Engenharia & Obras',
    location: 'Ribeirão Preto - SP',
    result: 'Fechamento de contrato de 6 dígitos',
    quote:
      'Nosso site antigo parecia feito há 10 anos. A AURUM refez todo o posicionamento com uma elegância ímpar. Na primeira reunião com um cliente grande, eles elogiaram nosso site institucional. Valeu cada centavo.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Juliana Prado',
    role: 'Proprietária',
    company: 'L’Essence Moda & Acessórios',
    location: 'Curitiba - PR',
    result: 'Vendas diárias triplicadas',
    quote:
      'Eu tinha medo de gastar e o site demorar 2 meses para sair. Na AURUM foi direto ao ponto: site lindo, rápido e focado em vender. Em menos de 24 horas minha loja estava no ar e já faturando.',
    rating: 5,
  },
  {
    id: '4',
    name: 'Rafael Guimarães',
    role: 'Sócio-Diretor',
    company: 'Guimarães & Associados',
    location: 'Campinas - SP',
    result: '+120% em contatos qualificados',
    quote:
      'Trabalho impecável de design e foco comercial. Não é só um site bonito, é uma ferramenta de captação de clientes que realmente funciona e passa a autoridade que o nosso escritório precisava.',
    rating: 5,
  },
];

export const PROCESS_STEPS = [
  {
    step: '01',
    title: 'Briefing Direto via WhatsApp',
    description:
      'Você nos conta sobre sua empresa, seus concorrentes e o que quer vender. Sem reuniões desnecessárias de horas: 15 minutos são suficientes.',
    time: '15 minutos',
  },
  {
    step: '02',
    title: 'Desenvolvimento Ágil & Design Estratégico',
    description:
      'Estruturamos toda a narrativa, o design visual e a programação do site focando em velocidade máxima e persuasão de compra.',
    time: 'Durante o dia',
  },
  {
    step: '03',
    title: 'Publicação e Entrega no Mesmo Dia',
    description:
      'Seu site é revisado, conectado ao seu domínio e colocado no ar pronto para receber clientes e começar a gerar faturamento.',
    time: 'Até 24h / Mesmo dia',
  },
];
